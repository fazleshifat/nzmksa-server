import mongoose, { Document, Schema } from "mongoose";

export interface IEmployee extends Document {
  password: string;
  name: string;
  residentIdNumber: string;
  idVersion?: string;
  nationality?: string;
  birthCity?: string;
  birthCountry?: string;
  dateOfBirth?: string;
  maritalStatus?: string;
  sponsorshipTransfers?: number;
  religion?: string;
  occupation?: string;
  employer?: string;
  employerIdNumber?: string;
  issuePlace?: string;
  workPermit?: string;
  residentIdIssueDate?: string;
  residentIdExpiry?: string;
  sponsorName?: string;
  sponsorIdNumber?: string;
  avatarUrl?: string;
  avatarPublicId?: string;

  passport?: {
    amountDeposit?: string;
    passportNumber?: string;
    type?: string;
    issuingDate?: string;
    expiryDate?: string;
    issuingCity?: string;
    status?: string;
  };

  healthInsurance?: {
    issuingDate?: string;
    expiryDate?: string;
  };

  hajjDetails?: {
    status?: string;
    lastHajjYear?: string;
  };

  qrData?: {
    name?: string;
    residentIdNumber?: string;
    nationality?: string;
    dateOfBirth?: string;
    sponsorName?: string;
    sponsorIdNumber?: string;
  };

  iqamaImage?: string;
  iqamaPublicId?: string;
  createdAt: Date;
  updatedAt: Date;
}

const employeeSchema = new Schema<IEmployee>(
  {
    password: { type: String, required: true, select: false },

    name: { type: String, required: true, trim: true },
    residentIdNumber: { type: String, required: true, unique: true, index: true },
    idVersion: String,
    nationality: String,
    birthCity: String,
    birthCountry: String,
    dateOfBirth: String,
    maritalStatus: String,
    sponsorshipTransfers: Number,
    religion: String,
    occupation: String,
    employer: String,
    employerIdNumber: String,
    issuePlace: String,
    workPermit: String,
    residentIdIssueDate: String,
    residentIdExpiry: String,
    sponsorName: String,
    sponsorIdNumber: String,

    avatarUrl: String,
    avatarPublicId: String,

    passport: {
      amountDeposit: String,
      passportNumber: String,
      type: String,
      issuingDate: String,
      expiryDate: String,
      issuingCity: String,
      status: String,
    },

    healthInsurance: {
      issuingDate: String,
      expiryDate: String,
    },

    hajjDetails: {
      status: String,
      lastHajjYear: String,
    },

    qrData: {
      name: String,
      residentIdNumber: String,
      nationality: String,
      dateOfBirth: String,
      sponsorName: String,
      sponsorIdNumber: String,
    },

    iqamaImage: String,
    iqamaPublicId: String,
  },
  { timestamps: true }
);

export const Employee = mongoose.model<IEmployee>("Employee", employeeSchema);